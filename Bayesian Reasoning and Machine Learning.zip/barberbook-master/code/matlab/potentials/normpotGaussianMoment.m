function newpot=normpotGaussianMoment(pot)
newpot=pot;