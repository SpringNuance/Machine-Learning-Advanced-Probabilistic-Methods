The Political books data was downloaded from http://www-personal.umich.edu/~mejn/netdata/
The original data was compiled by Valdis Krebs and was available from http://www.orgnet.com/
