function ns=numstatesGaussianMoment(pot)
ns=pot.table.dim;