function ns=numstatesGaussianCanonical(pot)
ns=pot.table.dim;