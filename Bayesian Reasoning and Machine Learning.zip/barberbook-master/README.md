# Bayesian Reasoning and Machine Learning

Solutions for David Barber's "Bayesian Reasoning and Machine Learning" Book

![frontcover](http://web4.cs.ucl.ac.uk/staff/D.Barber/textbook/jacket.gif)

[Webpage](http://web4.cs.ucl.ac.uk/staff/D.Barber/pmwiki/pmwiki.php?n=Brml.HomePage)

[PDF Copy v.2020](http://web4.cs.ucl.ac.uk/staff/D.Barber/textbook/200620.pdf)
