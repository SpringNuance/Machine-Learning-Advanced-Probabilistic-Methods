function [ind val]=argmax(x)
%ARGMAX performs argmax returning the index and value
% [ind val]=argmax(x)
[val ind]=max(x);