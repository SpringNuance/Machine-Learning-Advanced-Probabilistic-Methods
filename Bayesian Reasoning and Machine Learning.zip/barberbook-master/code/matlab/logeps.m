function y=logeps(x)
%LOGEPS  log(x+eps)
y=log(x+eps);